package com.ks.demo.simulator;

/**
 * The game broad class with the size of the broad and the a c to check if the position is a valid position
 */
public class SquareBoard  {
    int rows;
    int columns;

    public SquareBoard(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
    }
//validate the position X,Y which cannot be bigger than game broad row and column size and X, Y >0 
    public boolean isValidPosition(Position position) {
        return !(
                position.getX() > this.columns || position.getX() < 0 ||
                        position.getY() > this.rows || position.getY() < 0
        );
    }
}
