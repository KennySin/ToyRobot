package com.ks.demo.simulator;

/**
 * ENUM class to store the valid command of the robot
 */
public enum Command {
    PLACE,
    MOVE,
    LEFT,
    RIGHT,
    REPORT
}
