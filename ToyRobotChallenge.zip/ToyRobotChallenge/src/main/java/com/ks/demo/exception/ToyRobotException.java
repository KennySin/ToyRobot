package com.ks.demo.exception;

public class ToyRobotException extends Exception {

    private static final long serialVersionUID = 4234567654454L;

    public ToyRobotException(String string) {
        super(string);
    }

}
